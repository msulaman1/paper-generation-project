import './App.css';
import Mdiv from './components/navbar';
import Product from './components/product';

function App() {
  return (
    <>
     <div className='abcd'>
      <Mdiv/>
      </div>
      <Product/>
      
    
    </>
  );
}

export default App;

