const ProductData = [


    {
        id: 1,
        Title: 'product 1',
        img: './images/imga.jfif',
        price: 200 ,
        Des: 'The iPhone 11 has a 6.1-inch (15 cm) IPS LCD with a resolution is 1792  828 pixels (1.4 megapixels) at a pixel density of 326 PPI with a maximum brightness of 625 nits and a 1400:1 contrast ratio and it is equivalent to the iPhone XR.',
        cat: 'mobile'
    },

    {
        id: 2,
        Title: 'product 2',
        img: './images/imgb.jfif',
        price: 200 ,
        Des: 'The iPhone 11 has a 6.1-inch (15 cm) IPS LCD with a resolution is 1792  828 pixels (1.4 megapixels) at a pixel density of 326 PPI with a maximum brightness of 625 nits and a 1400:1 contrast ratio and it is equivalent to the iPhone XR. ',
        cat: 'mobile'
    },

    {
        id: 3,
        Title: 'product 3',
        img: './images/imgc.jfif',
        price: 200 ,
        Des: 'The iPhone 11 has a 6.1-inch (15 cm) IPS LCD with a resolution is 1792  828 pixels (1.4 megapixels) at a pixel density of 326 PPI with a maximum brightness of 625 nits and a 1400:1 contrast ratio and it is equivalent to the iPhone XR. ',
        cat: 'mobile'
    },
    {
        id: 4,
        Title: 'product 4',
        img: './images/imgd.jfif',
        price: 200 ,
        Des: 'The iPhone 11 has a 6.1-inch (15 cm) IPS LCD with a resolution is 1792  828 pixels (1.4 megapixels) at a pixel density of 326 PPI with a maximum brightness of 625 nits and a 1400:1 contrast ratio and it is equivalent to the iPhone XR.',
        cat: 'mobile'
    },
    {
        id: 5,
        Title: 'product 5',
        img: './images/imge.jfif',
        price: 200 ,
        Des: 'The iPhone 11 has a 6.1-inch (15 cm) IPS LCD with a resolution is 1792  828 pixels (1.4 megapixels) at a pixel density of 326 PPI with a maximum brightness of 625 nits and a 1400:1 contrast ratio and it is equivalent to the iPhone XR.',
        cat: 'mobile'
    },
    {
        id: 6,
        Title: 'product 6',
        img: './images/imgf.jfif',
        price: 200 ,
        Des: 'The iPhone 11 has a 6.1-inch (15 cm) IPS LCD with a resolution is 1792  828 pixels (1.4 megapixels) at a pixel density of 326 PPI with a maximum brightness of 625 nits and a 1400:1 contrast ratio and it is equivalent to the iPhone XR.',
        cat: 'mobile'
    },

]


export default ProductData;