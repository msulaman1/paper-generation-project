
// app.js


// import './App.css';
// import Mdiv from './components/navbar';
// import ProductBox from './components/ProductBox';
// import { productsdata } from './components/productsdata';


// function App() {
//   return (
//     <>
//     <div className='abcd'>
//       <Mdiv/>
      
//     </div>
//     <div className='flex'>
//     {productsdata.map((product) => (
//        < ProductBox key={product.id} product={product} />
//       ))}
//       </div>
    
//     </>
//   );
// }

// export default App;





// ProductBox.js



// import React from 'react';
// // import "./ProductBox.css"
// const ProductBox = ({ product }) => {
//   return (
//     <div className="product-box">

//       <img  src={product.image} alt={product.title} />
//       <h3>{product.title}</h3>
//       <p>${product.price}</p>
//     </div>
//   );
// };

// export default ProductBox;

// productsdata.js

// import {SliderData} from "./SliderData"

// export const productsdata=[
//     {
//         id: 1,
//         title: 'Iphone',
//         price: 30.00,
//         image: SliderData[0].image,
//     },
//     {
//         id: 2,
//         title: 'Laptop',
//         price: 30.00,
//         image: SliderData[1].image,
//     },
//     {
//         id: 3,
//         title: 'Iphone',
//         price: 30.00,
//         image: SliderData[2].image,
//     },
//     {
//         id: 4,
//         title: 'Iphone',
//         price: 30.00,
//         image: SliderData[3].image,
//     },
// ]





// app.css


// .body
// {
//   margin: 0;
//   padding: 0;
// }
// .abcd
// {
//   height: 80px;
// }
// .product-box>img 
// {
//   width: 80%;
//   height: 300px;
 
 
// }
// .flex{
//   display: flex;
//   width: 100%;
//   padding: 60px;
//   height: 400px;
// }




// imageslider.ccs


// body
// {
//     margin: 0;
//     padding: 0;
// }
// .slide-container
// {
//     display: flex;
//     align-items: center;
//     height: 400px;
//     padding-left: 50px;
//     padding-top: 50px;
//     display: flex;
    
// }
// img 
// {
//     margin-left: 120px;
//     display: flex;
    
// }



// SliderData.jsx

// export const SliderData = [
//     {
//       image:
//         'https://images.unsplash.com/photo-1546768292-fb12f6c92568?ixid=MXwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHw%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80'
//     },
//     {
//       image:
//         'https://images.unsplash.com/photo-1501446529957-6226bd447c46?ixlib=rb-1.2.1&ixid=MXwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHw%3D&auto=format&fit=crop&w=1489&q=80'
//     },
//     {
//       image:
//         'https://images.unsplash.com/photo-1483729558449-99ef09a8c325?ixlib=rb-1.2.1&ixid=MXwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHw%3D&auto=format&fit=crop&w=1350&q=80'
//     },
//     {
//       image:
//         'https://images.unsplash.com/photo-1475189778702-5ec9941484ae?ixlib=rb-1.2.1&ixid=MXwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHw%3D&auto=format&fit=crop&w=1351&q=80'
//     },
//     {
//       image:
//         'https://images.unsplash.com/photo-1503177119275-0aa32b3a9368?ixlib=rb-1.2.1&ixid=MXwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHw%3D&auto=format&fit=crop&w=1350&q=80'
//     }
//   ];
