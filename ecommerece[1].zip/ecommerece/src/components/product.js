import React, { useState } from 'react'
import ProductData from './productData'
import './style.css';

const Product = () => {
    const [detail,setdetail] = useState([]);
    const [close,setclose]  = useState(false)
    const detailPage = (Product) =>
    {
        setdetail([{...Product}])
        setclose(true)
        
    }


  return (
  <>
  {
    close ?
    <div className='detail_container'>
    <div className='detail_contant'>
 <button className='close' onClick={() => setclose(false)}>  <i class="fa-solid fa-xmark"></i> </button> 
        {
            detail.map((x) =>
            {
                return(
                    <>
                    <div className='detail_info'>
                        <div className='img-box'>
                            <img src={x.img} alt={x.Title}></img>
                        </div>
                        <div className='product_detail'>
                            <h2>{x.Title}</h2>
                            <h3> $ {x.price}</h3>
                            <p>{x.Des}</p>
                            <button>add to cart</button>
                        </div>
                    </div>
                    
                    
                    </>
                )
            }
            
            )
        }
    </div>
  </div> :null
  }

  <div className='conatiner'>
    {
        ProductData.map((curELm) =>
        {
            return(
                <>
                <div className='box'>
                    <div className='contant'>
                        <div className='img-box'>
                            <img src={curELm.img} alt={curELm.Title}></img>
                        </div>
                        <div className='detail'>
                            <div className='info'></div>
                            <h3>{curELm.Title}</h3>
                            <p>{curELm.price}</p>
                        </div>
                       
                    </div>
                    <button onClick={() => detailPage(curELm)} className='btn1'>view</button> 
                </div>
                
                </>
            )
        }
        )
    }



  </div>
  
  </>
  )
}

export default Product;

