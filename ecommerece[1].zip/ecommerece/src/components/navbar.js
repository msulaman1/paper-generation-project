import React from 'react';
import './navbar.css';


function Mdiv() {
    return (
    <div className='main'>
     <nav >
       <ul className='Start_a'>
          <li className='aaa'><a href=''><b>logo</b></a></li>
          <li><a href=''><b>About</b></a></li>
          <li><a href=''><b>Categories</b></a></li>
          <li><a href=''><b>Information</b></a></li>
          <li><a href=''><b>Events</b></a></li>
         
          <input type='text' placeholder='search' />
        <a className='f_icon' href=''><i class="fa-solid fa-magnifying-glass"></i></a> 
          <a className='b_icon' href=''><i class="fa-solid fa-cart-shopping"></i></a>
         <div className='btn'> 
      <li>   <a> <button type='submit'>log IN</button></a> </li>
     <li>   <a>  <button type='submit'>REGISTER</button></a> </li>
          </div>
       </ul>
       
     </nav>

    </div>
);
};
  
  export default Mdiv;